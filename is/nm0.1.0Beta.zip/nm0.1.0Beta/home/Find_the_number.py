import random
import time
import sys
import os
from colorama import Fore, Style
Pointadd = 0
def clear(Pass_or_not):
    if Pass_or_not == True:
        print("You passed the game")
        time.sleep(3)
        wh = 0
        while True:
            time.sleep(.0001)
            print('\033[92m'+str(random.randint(0,1))+'\033[0m', end="",flush=True)
            wh += 1
            if wh >= 3000:
                sys.exit()
    else:
        print("You failed the game")
print("easy = 1\nnormal = 2\nhard = 3")
mode = input("Please select : ")
try:
    mode = int(mode.strip())
except ValueError:
    print("Error")
    sys.exit(0)
if mode >= 5 or mode <= 0:
    print("Error")
    sys.exit(0)

if mode == 1:
    print("easy")
    length = 3
    length_l, length_h = 111, 999
    Response = 12
    Pointadd = 1
    time.sleep(1)
elif mode == 2:
    print("normal")
    length = 5
    length_l, length_h = 11111, 99999
    Response = 8
    Pointadd = 3
    time.sleep(1)
elif mode == 3:
    print("hard")
    length = 7
    length_l, length_h = 1111111, 9999999
    Response = 5
    Pointadd = 6
    time.sleep(1)
elif mode == 4:
    print("impossible")
    length = 15
    length_l, length_h = 111111111111111, 999999999999999
    Response = 3
    Pointadd = 13
    time.sleep(1)

x = []
y = None
safe = []
ck = []

while True:
    x += [random.randint(length_l, length_h)]
    if len(x) >= 30 and mode != 4:
        break
    elif len(x) >= 50 and mode == 4:
        break
if mode != 4:
    y = random.randint(0, 29)
elif mode == 4:
    y = random.randint(0, 49)
z = x[y]
def Selectdef(SelectSelectdef):
    print("Verification...")
    nm = 0
    while True:
        if nm >= 100:
            nm = 100
            break
        time.sleep(0.3)
        nm += random.randint(10, 30)
        print(f"\rUnder review... {nm}%", end="", flush=True)
    for i, v in enumerate(x):
        print("\r", i, v, SelectSelectdef)
        if v == SelectSelectdef:
            print(v, "==", SelectSelectdef)
            global safe
            safe.append(v)
            global The_selected_one
            global Response
            Response -= 1
            if length == 3:
                x[i] = "---"
            elif length == 5:
                x[i] = "-----"
            elif length == 7:
                x[i] = "-------"
            elif length == 15:
                x[i] = "---------------"
            return True

    return False
def cheap(number):
    ckin = ""
    numberstr = str(number)
    The_correct_one = str(z)
    for i in range(length):
        The_correct_one[i]
        numberstr[i]
        if int(The_correct_one[i]) == int(numberstr[i]):
            print(numberstr[i], end ="", flush=True)
            ckin = ckin + str(numberstr[i])
        else:
            print("-", end="", flush=True)
            ckin = ckin + "-"
    global ck
    ck.append(ckin)
    if number == z:
        print("\n---------------------------------------------------------------\n\n\n           correct\n\n\n---------------------------------------------------------------")
        clear(True)
    else:
        st()
def Continue(SelectContinue):
    if type(SelectContinue) != int or SelectContinue < length_l or SelectContinue > length_h:
        print("Error")
        st()
        return
    if Selectdef(SelectContinue):
        print("\rCheck successful", end="\n", flush=True)
        print("have", SelectContinue)
        cheap(SelectContinue)
    else:
        print("\rdo not have", SelectContinue, end="\n", flush=True)
        st()

def st():
    if Response <= 0:
        clear(False)
        return
    l1 = [x[0:10]]
    l2 = [x[10:20]]
    l3 = [x[20:30]]
    l4 = [x[30:40]]
    l5 = [x[40:50]]
    print("\nType 'exit' to exit the game")
    print(l1)
    print(l2)
    print(l3)
    if mode == 4:
        print(l4)
        print(l5)
    print("You have", Response, "chances left")
    Select = input("Select : ")
    if Select.lower().strip() == "exit":
        sys.exit(0)
    elif Select.lower().strip() == "ck":
        for i, sf, in enumerate(safe):
            print(sf, end="   ")
            print(ck[i])
        st()
    elif Select.lower().strip() == "help":
        print("\n\n\nexit == Exit the program\nck == Check code\nhelp == You know that.\n\n\n")
        st()
    try:
        Select_Convert_value = int(Select.strip())
    except ValueError:
        print("Error")
        st()
        return
    Continue(Select_Convert_value)

st()